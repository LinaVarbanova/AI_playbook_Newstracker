#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# shellcheck disable=SC1091
source .venv/bin/activate
exec python -m uvicorn web.app:app --host 127.0.0.1 --port 8765 --reload
