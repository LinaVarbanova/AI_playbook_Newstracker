#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"

echo "==> Creating venv in $ROOT/.venv"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate

echo "==> Installing dependencies"
pip install --upgrade pip
pip install -r requirements.txt

echo "==> Initializing DB"
python -c "from storage import db; db.init_db(); print('DB ready at', db.DB_PATH)"

echo "==> Done. Next steps:"
echo "   1. Run one-shot collection:    python scheduler.py"
echo "   2. Start the web UI:           python -m uvicorn web.app:app --host 127.0.0.1 --port 8765"
echo "   3. Install launchd 12h job:    bash scripts/install_launchd.sh"
